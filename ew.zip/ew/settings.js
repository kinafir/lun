global.prefa = ['', '!', '.', ',', '🐤', '🗿'] //jangan di rename

global.owner = ['6289527229227'] //nomormu
global.botname = 'Bot Sange' //nama bot

global.versionsc = "5.0" //jangan direname
global.creatorbot = "ZEROX WARZ" //jangan direname
global.baileys1 = require('@whiskeysockets/baileys') //jangan direname


var _0x4ee5cf = _0x5ade;

function _0x5ade(_0x3537aa, _0x321df7) {
    var _0x1362f3 = _0x1362();
    return _0x5ade = function (_0x5ade66, _0x2035df) {
        _0x5ade66 = _0x5ade66 - 0x76;
        var _0x5a3d1f = _0x1362f3[_0x5ade66];
        return _0x5a3d1f;
    }, _0x5ade(_0x3537aa, _0x321df7);
}(function (_0x2f58cc, _0x32d567) {
    var _0x2339db = _0x5ade,
        _0x2ed757 = _0x2f58cc();
    while (!![]) {
        try {
            var _0x3acbae = parseInt(_0x2339db(0x7b)) / 0x1 + -parseInt(_0x2339db(0x80)) / 0x2 * (parseInt(_0x2339db(0x89)) / 0x3) + -parseInt(_0x2339db(0x8a)) / 0x4 * (-parseInt(_0x2339db(0x7a)) / 0x5) + -parseInt(_0x2339db(0x7c)) / 0x6 + parseInt(_0x2339db(0x82)) / 0x7 * (-parseInt(_0x2339db(0x84)) / 0x8) + -parseInt(_0x2339db(0x7e)) / 0x9 + parseInt(_0x2339db(0x86)) / 0xa * (parseInt(_0x2339db(0x7d)) / 0xb);
            if (_0x3acbae === _0x32d567) break;
            else _0x2ed757['push'](_0x2ed757['shift']());
        } catch (_0x2b8b7e) {
            _0x2ed757['push'](_0x2ed757['shift']());
        }
    }
}(_0x1362, 0x8b838), global[_0x4ee5cf(0x81)] = _0x4ee5cf(0x83), global[_0x4ee5cf(0x77)] = _0x4ee5cf(0x87), global[_0x4ee5cf(0x76)] = _0x4ee5cf(0x78), global[_0x4ee5cf(0x88)] = _0x4ee5cf(0x7f), global[_0x4ee5cf(0x85)] = _0x4ee5cf(0x8b), global[_0x4ee5cf(0x79)] = '`[ # ] ZEROX WARZ` \x0acommand khusus admin!');

function _0x1362() {
    var _0x4b3a44 = ['nobotadmin', '70dCqVUG', '`[ # ] ZEROX WARZ ` \x0acommand khusus owner!', 'noingroup', '3IuSgxi', '73172MZBeHu', '`[ # ] ZEROX WARZ` \x0agagal, bot harus jadi admin!', 'notext', 'spesialown', '`[ # ] ZEROX WARZ` \x0ano text! harap sertakan teks!', 'usernoadmin', '225XwgoZl', '158394wEefnY', '248136qmIRJq', '1929851lMbNtc', '5775822QcAYLo', '`[ # ] ZEROX WARZ` \x0acommand khusus di grup!', '1811644XghmlV', 'spesialprem', '574ipuWwA', '`[ # ] ZEROX WARZ` \x0acommand khusus premium!', '4808qzygMe'];
    _0x1362 = function () {
        return _0x4b3a44;
    };
    return _0x1362();
}