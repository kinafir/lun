global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['85224415645']
global.botname = 'Bot Gaje'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "wangsaff Official"
global.sticker2 = "🌜"